-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Oct 28, 2014 at 10:23 AM
-- Server version: 5.5.38
-- PHP Version: 5.6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `theproject`
--
CREATE DATABASE IF NOT EXISTS `theproject` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `theproject`;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
`auto_id` int(11) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `date_published` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`auto_id`, `title`, `description`, `date_published`) VALUES
(1, 'test', 'test', '2014-10-28 06:02:55'),
(2, 'test2', 'test2test2', '2014-10-28 08:39:45'),
(3, 'test3', 'test3test3', '2014-10-28 08:40:05'),
(4, 'test4', 'test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 test4test4test4test4test4test4test4test4test4test4test4test4 ', '2014-10-28 09:05:13');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
`auto_id` bigint(20) NOT NULL,
  `person_id` varchar(20) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `admin_level` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `upper_person_id` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`auto_id`, `person_id`, `firstname`, `lastname`, `admin_level`, `password`, `email`, `upper_person_id`) VALUES
(1, '1669800051735', 'Siwawes', 'Wongcharoen', 0, '1234', 'siwaoh@gmail.com', ''),
(2, '1234567890123', 'test', 'test', 100, 'test', 'test', ''),
(3, 'test2', 'test2', 'test2', 100, '1234', 'ttt@ttt.com', '1669800051735'),
(5, 'test3', 'test3', 'test3', 100, '1234', 'zzz@zzz.com', '1669800051735');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
 ADD PRIMARY KEY (`auto_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`auto_id`), ADD UNIQUE KEY `person_id` (`person_id`), ADD UNIQUE KEY `email` (`email`), ADD KEY `upper_person_id` (`upper_person_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
MODIFY `auto_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `auto_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
